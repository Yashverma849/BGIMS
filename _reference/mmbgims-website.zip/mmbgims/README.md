# MM BGIMS — Heritage Reimagined

A premium, end-to-end website for **Maratha Mandir's Babasaheb Gawde Institute of Management Studies**, Mumbai.

**Aesthetic direction:** _Modern Heritage_ — editorial sophistication of HBS / INSEAD / LBS websites married to the cultural warmth of premium Indian heritage brands. Built to make a 23-year-old institution feel like an institution worth applying to.

---

## How to run

This is a static, multi-page website. No build step required.

```bash
# From this folder, simply serve the files
python3 -m http.server 8080
# then visit http://localhost:8080
```

You can also open `index.html` directly in any modern browser.

---

## What's included

### Public website (10 pages)

| Page | Purpose |
|---|---|
| `index.html` | Home — hero, heritage, programmes, faculty, testimonials, recruiters, events, CTA |
| `about.html` | Heritage, Maratha Mandir, vision & mission, leadership messages, governing body |
| `programs.html` | MBA Banking & Finance, MMS, BMS, Ph.D — full curricula |
| `placements.html` | Placement record, top placements, sector distribution, year-on-year, recruiters |
| `faculty.html` | Director, core faculty, visiting authorities |
| `events.html` | News & events archive with category filters |
| `alumni.html` | Alumni network, notable alumni, spotlight, member privileges |
| `contact.html` | Address, phone, email, enquiry form, map |
| `admissions.html` | Eligibility, process, fee structure, scholarships |
| `apply.html` | 5-step application form with **mock Razorpay payment flow** |

### CMS / Admin (2 pages)

| Page | Purpose |
|---|---|
| `admin/login.html` | Sign-in screen — demo credentials: `director@mmbgims.com` / `bgims2026` |
| `admin/dashboard.html` | Full admin dashboard: KPIs, applications, enquiries, payments, content editor, CSV export |

The CMS reads **real applications** submitted through `apply.html` (stored in `localStorage`) and lets the institute filter, view, and export them. Click _"Seed Demo Data"_ in the dashboard to populate sample applications.

### Assets

- `assets/css/main.css` — 1,500+ line design system (tokens, typography, components, layouts, motion)
- `assets/js/main.js` — Page loader, scroll progress, custom cursor, magnetic buttons, reveal-on-scroll observer, animated counters, hero word stagger, testimonial slider, marquee, application stepper, payment modal, enquiry form handlers, lightweight CMS store

---

## Brand identity

| Token | Value | Use |
|---|---|---|
| **Maroon (primary)** | `#722325` | Authority, heritage |
| **Brass gold** | `#B8965A` | Luxury accents |
| **Peacock teal** _(personality)_ | `#0F4C4C` | Tertiary character / Indian heritage warmth |
| **Cream / parchment** | `#F5EFE3` | Background |
| **Ink** | `#0F0C0A` | Text, dark sections |

**Typography stack:**
- **Cormorant Garamond** (display) — elegant serif headlines
- **Fraunces** (display alt) — variable serif for editorial details
- **Italiana** (italic accent) — distinctive italics for "tomorrow's" / "moments" / etc.
- **Manrope** (body) — humanist sans for prose
- **JetBrains Mono** (mono) — IDs, codes, applications

---

## Design references

The site distills patterns from premium B-school websites worldwide:
Harvard Business School, Stanford GSB, Wharton, INSEAD, London Business School, IIM Ahmedabad, ISB, MIT Sloan, Booth Chicago, Kellogg, Yale SOM, Columbia, NYU Stern, Tuck Dartmouth, Darden UVA, Cornell Johnson, HEC Paris, Cambridge Judge, Oxford Saïd, Rotman.

Key principles applied:
- **Restrained palette** with one personality colour
- **Serif headlines / sans body**
- **Editorial layouts** — grid with intentional grid-breaking moments
- **Numbers as proof points** (animated counters)
- **Faculty as thought-leaders**, not photo stock
- **Heritage storytelling** ("23 years", "since 2002", "Mumbai's mercantile imagination")
- **Subtle motion** — never gaudy

---

## Premium animations & interactions

- **Page loader** — full-screen ink loader with brass mark, scaleY exit
- **Custom cursor** — accent-coloured ring with hover-state expansion (desktop only)
- **Magnetic buttons** — subtle pull-to-cursor on primary CTAs
- **Hero word reveal** — staggered translateY with cubic-elegant easing
- **Floating particles** — slow-drifting brass dots in hero background
- **Number counters** — count-up on scroll with ease-out-quart
- **Reveal-on-scroll** — IntersectionObserver-driven fade & rise
- **Testimonial slider** — auto-advance with manual nav
- **Recruiter marquee** — infinite-loop horizontal scroll
- **Programme cards** — hover lift, gold underline reveal
- **Filter chips on events** — instant client-side filter
- **Year-on-year ladder** — scaleX bar reveal on intersection
- **Sector cells** — full-cell colour invert on hover
- **Apply form** — multi-step with progress, scroll-to-step, animated Razorpay modal
- **Smooth scrolling, scroll progress bar, sticky nav**

---

## CMS / Payment workflow

1. Visitor lands on `apply.html`, fills 5-step form, picks programme (auto-calculates fee + 18% GST)
2. Selects payment method (UPI / card / netbanking / wallet)
3. **Razorpay-style mock modal** opens, simulates bank handshake (3.2s), then shows success state with application ID, payment ID, and receipt
4. Application is stored in `localStorage` under `mmbgims_applications`
5. Institute logs in at `admin/login.html`, dashboard loads at `admin/dashboard.html` and reads the same store
6. Director can: filter applications, view counts, see programme distribution, track payments, export CSV, edit homepage content

To wire up a real payment gateway later, replace the mock in `apply.html` (lines ~620–700) with a real Razorpay SDK call. The data shape is already production-ready.

---

## File tree

```
mmbgims/
├── index.html            home
├── about.html            about / heritage
├── programs.html         programmes
├── placements.html       placements (NEW)
├── faculty.html          faculty
├── events.html           events & news (NEW)
├── alumni.html           alumni network (NEW)
├── contact.html          contact
├── admissions.html       admissions process
├── apply.html            5-step application + payment
├── README.md             this file
├── admin/
│   ├── login.html        CMS sign-in
│   └── dashboard.html    CMS dashboard
└── assets/
    ├── css/main.css      design system
    ├── js/main.js        interactions
    └── img/              (placeholder for institute photography)
```

---

## To customise

- **Colours** — edit the `:root` block at the top of `assets/css/main.css`
- **Fonts** — change Google Fonts links in each `<head>` and the `--font-*` tokens in CSS
- **Copy** — every page is a flat HTML file with editable copy
- **Faculty/programme/event data** — currently hard-coded in HTML. Swap the static markup for a fetch from your CMS (or wire it to the existing `localStorage` admin)
- **Real photography** — drop institute photos into `assets/img/` and replace SVG placeholders in hero/feature/event cards

---

© 2026 — A reference build. Adapt freely.
