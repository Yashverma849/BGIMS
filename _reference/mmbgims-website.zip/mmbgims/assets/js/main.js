/* ============================================================
   MMBGIMS — Interactions & Animations
   ============================================================ */

(() => {
  'use strict';

  /* ───── Page Loader ───── */
  window.addEventListener('load', () => {
    const loader = document.querySelector('.page-loader');
    if (loader) {
      setTimeout(() => loader.classList.add('done'), 400);
      setTimeout(() => loader.remove(), 1300);
    }
  });

  /* ───── Scroll Progress ───── */
  const progress = document.querySelector('.scroll-progress');
  if (progress) {
    window.addEventListener('scroll', () => {
      const h = document.documentElement;
      const pct = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
      progress.style.width = pct + '%';
    }, { passive: true });
  }

  /* ───── Sticky nav with scroll detection ───── */
  const nav = document.querySelector('.nav');
  if (nav) {
    let last = 0;
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      nav.classList.toggle('scrolled', y > 60);
      last = y;
    }, { passive: true });
  }

  /* ───── Mobile menu toggle ───── */
  const burger = document.querySelector('.nav__hamburger');
  const menu = document.querySelector('.nav__menu');
  if (burger && menu) {
    burger.addEventListener('click', () => {
      burger.classList.toggle('open');
      menu.classList.toggle('open');
    });
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      burger.classList.remove('open');
      menu.classList.remove('open');
    }));
  }

  /* ───── Reveal on scroll (IntersectionObserver) ───── */
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

  document.querySelectorAll('.reveal, .reveal-line').forEach(el => observer.observe(el));

  /* ───── Custom cursor ───── */
  if (window.matchMedia('(hover: hover) and (pointer: fine)').matches && !window.matchMedia('(max-width: 768px)').matches) {
    const cursor = document.createElement('div');
    cursor.className = 'cursor';
    document.body.appendChild(cursor);

    let mx = 0, my = 0, cx = 0, cy = 0;
    document.addEventListener('mousemove', (e) => { mx = e.clientX; my = e.clientY; });
    const tick = () => {
      cx += (mx - cx) * 0.18;
      cy += (my - cy) * 0.18;
      cursor.style.transform = `translate(${cx}px, ${cy}px) translate(-50%, -50%)`;
      requestAnimationFrame(tick);
    };
    tick();

    document.querySelectorAll('a, button, .program-card, .event, .person, [data-cursor]').forEach(el => {
      el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
      el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
    });
  }

  /* ───── Magnetic buttons ───── */
  document.querySelectorAll('[data-magnetic]').forEach(btn => {
    const strength = 0.25;
    btn.addEventListener('mousemove', (e) => {
      const rect = btn.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      btn.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = '';
    });
  });

  /* ───── Number Counter ───── */
  const counterObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseInt(el.dataset.count, 10);
      const duration = 1800;
      const start = performance.now();
      const animate = (now) => {
        const t = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - t, 4);
        el.querySelector('.num').textContent = Math.floor(eased * target).toLocaleString();
        if (t < 1) requestAnimationFrame(animate);
        else el.querySelector('.num').textContent = target.toLocaleString();
      };
      requestAnimationFrame(animate);
      counterObs.unobserve(el);
    });
  }, { threshold: 0.4 });
  document.querySelectorAll('[data-count]').forEach(el => counterObs.observe(el));

  /* ───── Hero floating particles ───── */
  const heroParticles = document.querySelector('.hero__particles');
  if (heroParticles) {
    for (let i = 0; i < 14; i++) {
      const p = document.createElement('span');
      p.className = 'particle';
      p.style.left = Math.random() * 100 + '%';
      p.style.animationDelay = Math.random() * 8 + 's';
      p.style.animationDuration = (8 + Math.random() * 6) + 's';
      heroParticles.appendChild(p);
    }
  }

  /* ───── Testimonial slider ───── */
  const slides = document.querySelectorAll('[data-testimonial]');
  if (slides.length > 1) {
    let idx = 0;
    const show = (i) => {
      slides.forEach((s, k) => s.style.display = k === i ? 'grid' : 'none');
    };
    show(0);
    document.querySelectorAll('[data-testimonial-prev]').forEach(b => b.addEventListener('click', () => {
      idx = (idx - 1 + slides.length) % slides.length;
      show(idx);
    }));
    document.querySelectorAll('[data-testimonial-next]').forEach(b => b.addEventListener('click', () => {
      idx = (idx + 1) % slides.length;
      show(idx);
    }));
    // auto-advance every 8s
    setInterval(() => { idx = (idx + 1) % slides.length; show(idx); }, 8000);
  }

  /* ───── Hero word reveal stagger ───── */
  document.querySelectorAll('.hero__title .word > span').forEach((w, i) => {
    w.style.animationDelay = (i * 0.08 + 0.4) + 's';
  });

  /* ───── Application form stepper ───── */
  const stepper = document.querySelector('[data-stepper]');
  if (stepper) {
    const steps = stepper.querySelectorAll('.step');
    const panels = document.querySelectorAll('[data-step-panel]');
    const next = document.querySelectorAll('[data-step-next]');
    const prev = document.querySelectorAll('[data-step-prev]');
    let current = 0;
    const update = () => {
      steps.forEach((s, i) => {
        s.classList.toggle('active', i === current);
        s.classList.toggle('complete', i < current);
      });
      panels.forEach((p, i) => p.style.display = i === current ? '' : 'none');
      window.scrollTo({ top: stepper.offsetTop - 100, behavior: 'smooth' });
    };
    next.forEach(b => b.addEventListener('click', () => { if (current < steps.length - 1) { current++; update(); } }));
    prev.forEach(b => b.addEventListener('click', () => { if (current > 0) { current--; update(); } }));
    update();
  }

  /* ───── Payment method selector ───── */
  document.querySelectorAll('.payment-method__option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.payment-method__option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
    });
  });

  /* ───── Demo: razorpay-style payment modal trigger ───── */
  const payBtn = document.querySelector('[data-pay-now]');
  if (payBtn) {
    payBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // Simulate processing
      const original = payBtn.innerHTML;
      payBtn.innerHTML = '<span class="spinner"></span> Processing…';
      payBtn.disabled = true;
      setTimeout(() => {
        const modal = document.querySelector('[data-success-modal]');
        if (modal) modal.classList.add('open');
        payBtn.innerHTML = original;
        payBtn.disabled = false;
      }, 1800);
    });
  }

  document.querySelectorAll('[data-modal-close]').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('open'));
  }));
  document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('open'); });
  });

  /* ───── Smooth scroll for anchor links ───── */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const id = link.getAttribute('href');
      if (id.length <= 1) return;
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ───── CMS: lightweight client-side store ───── */
  window.MMBGIMS = window.MMBGIMS || {};
  window.MMBGIMS.cms = {
    get(key, fallback) {
      try { return JSON.parse(localStorage.getItem('mmbgims:' + key)) ?? fallback; }
      catch { return fallback; }
    },
    set(key, value) { localStorage.setItem('mmbgims:' + key, JSON.stringify(value)); },
    remove(key) { localStorage.removeItem('mmbgims:' + key); }
  };

  /* ───── Form: contact / enquiry simulated submit ───── */
  document.querySelectorAll('[data-enquiry-form]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const data = Object.fromEntries(fd.entries());
      data.id = 'ENQ-' + Date.now().toString(36).toUpperCase();
      data.received = new Date().toISOString();
      const list = window.MMBGIMS.cms.get('enquiries', []);
      list.unshift(data);
      window.MMBGIMS.cms.set('enquiries', list);
      const msg = form.querySelector('[data-form-success]');
      if (msg) {
        msg.style.display = 'block';
        msg.textContent = `Thank you, ${data.name?.split(' ')[0] || 'friend'}. Your enquiry (${data.id}) has been received. Our admissions office will reach out within 1 business day.`;
      }
      form.reset();
    });
  });

})();
